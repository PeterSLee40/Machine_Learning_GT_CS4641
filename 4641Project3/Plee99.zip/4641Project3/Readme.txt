Username, Gtid = Plee99, 903309003

Python 3.6 Libraries needed:
	Numpy, sci-kit learn, matplotlib, Kneed, collections

Each experiment is broken into each file. Typically parameters like th number of clusters
can be edited at the top of the file and should be easy to find. I tried to include
the tage #edit wherever i edited to generated new graphs.

Folder information and organization:

/cluster - stores Kmeans and GMA experiments
/PCA - stores all the experiments relating to PCA and generatign 3d pca graphs
/PCAThenCluster - stores all experiments the involved using PCA then using GMM or K means
/NeuralNet - stores all the experiments that involve training a neural net after applying pca, gmm, kmeans

/SpaceData - stores the Space dataset, includes npy arrays that are called throughout this project.
/BreastData - stores the Breast Cancer dataset, includes npy arrays that are called throughout this project.



